var serverlessSDK = require('./serverless_sdk/index.js')
serverlessSDK = new serverlessSDK({
tenantId: 'gabecampbell',
applicationName: 'drinktionary-application',
appUid: 'b4c4rMZgfC6R8v8n89',
tenantUid: 'xFHSKpGnR8yKVHqZ9Y',
deploymentUid: '816a6f81-e1b6-49cd-a318-39d7e8e58bd9',
serviceName: 'drinktionary-app-api',
stageName: 'dev',
pluginVersion: '3.2.4'})
const handlerWrapperArgs = { functionName: 'drinktionary-app-api-dev-billing', timeout: 6}
try {
  const userHandler = require('./billing.js')
  module.exports.handler = serverlessSDK.handler(userHandler.main, handlerWrapperArgs)
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs)
}
